package szamologepszervlet.model;

public class NotSupportedOperationException extends RuntimeException {

}
